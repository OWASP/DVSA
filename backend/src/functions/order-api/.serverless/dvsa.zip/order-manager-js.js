require('@protego/protego-node-agent')();

var serialize = require('node_modules/node-serialize');
var AWS = require('aws-sdk');

exports.handler = (event, context, callback) => {

    var req = serialize.unserialize(event.body);
    var req = event.body;
    var action = req.action;
    console.log("ACTION => ", action);
    var isOk = true;
    var payload = {};
    
    switch(action) {
        case "new":
            payload = { "cartId": req["cart-id"], "items": req["items"] };
            break;
            
        case "update":
            payload = { "orderId": req["order-id"], "items": req["items"] };
            break;
            
        case "cancel":
            payload = { "orderId": req["order-id"] };
            break;
        
        case "get":
            payload = { "orderId": req["order-id"] };
            break;
            
        case "orders":
            payload = {"orders": ""};
            break;
        
        case "account":
            payload = {}; 
            break;
            
        case "profile":
            payload = {};
            break;
        
        case "cancel":
            payload = { "orderId": req["order-id"] };
            break;
            
        case "shipping":
            payload = { "orderId": req["order-id"], "shipping": req["data"] };
            break;
            
        case "billing":
            payload = { "orderId": req["order-id"], "billing": req["data"] };
            break;
            
        default:
            isOk = false;
    }
    
    if (isOk == true) {
        
        var lambda = new AWS.Lambda();
        var params = {
          FunctionName: 'DVSA-ORDER-' + action.toUpperCase(),
          InvocationType: 'RequestResponse',
          Payload: JSON.stringify(payload)
        };
        
        lambda.invoke(params, function(err, data) {
            if (err) {
                const response = {
                    statusCode: 403,
                    body: JSON.stringify(err),
                };
                callback(null, response);
            }
            else {
                const response = {
                    statusCode: 200,
                    body: JSON.stringify(data),
                };
                callback(null, response);

            }
        });
        
    }
    else {
        var data = {"status": "err", "msg": "unknown action"};
        const response = {
            statusCode: 403,
            body: JSON.stringify(data),
        };
        callback(null, response);

    }
};

